# Leitura do gabarito
with open("gabarito.txt", "r", encoding="utf-8") as arquivo:
    gabarito = arquivo.readline().strip().split(",")

# Lista para armazenar classificação
classificacao = []

# Leitura dos candidatos
with open("candidatos.txt", "r", encoding="utf-8") as arquivo:
    linhas = arquivo.readlines()

    for linha in linhas:
        dados = linha.strip().split(",")

        id_candidato = dados[0]
        nome = dados[1]
        respostas = dados[2:]

        nota = 0

        # Comparação das respostas
        for i in range(min(len(gabarito), len(respostas))):
            if respostas[i] == gabarito[i]:
                nota += 1

        classificacao.append([id_candidato, nome, nota])

# Geração do arquivo classificacao.txt
with open("classificacao.txt", "w", encoding="utf-8") as arquivo:
    for candidato in classificacao:
        linha = f"{candidato[0]},{candidato[1]},{candidato[2]}\n"
        arquivo.write(linha)

print("Classificação gerada com sucesso!")
